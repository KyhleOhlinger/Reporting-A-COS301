// Defining the IP Address of our server
var ipAddress = "127.0.0.1";

// Defining the port on which we want to listen
var portNumber = "1337"
// Importing necessary library files
var httpModule = require("http");

var htmlStart =
            "<html>"
            + "<title>Knock Knock Joke</title>";
 var   htmlEnd =
            "</div></body>"
            + "</html>";
        
          var inputString = "";
          var outputString = "";
	  var jokeCount = 0;

// Creating our server's main method
httpModule.createServer(
 function serviceRequest (request, response) {

  // Check what file the user has requested and take necessary action
  var queryString = new String(request.url);

  
	if (queryString == "/")
	{
		// HTML which we will display to the user
		var htmlContent = htmlStart + addDiv("") + jokeHTML() + htmlEnd;
		response.end(htmlContent);
	}
	else
	{
		var eq = queryString.indexOf("=");
		var jokeInput = queryString.substr(eq + 1, queryString.length - 1);
	
          
		if (jokeInput.toLowerCase() == "start")
		{
		      if(jokeCount == 0)
		      {
				outputString += "<p>You: START</p>";
				outputString += "<hr/>";
				outputString += "<p>Program: Knock knock</p>";
		      }
		      else
		      {
				outputString += "<p>You: START</p>";
				outputString += "<p>Program:  I'm sorry, I don't understand</p>";
		      }
		}
		else if (jokeInput.toLowerCase() == "who%27s+there%3f")
		{
			if(jokeCount == 0)
			{
				outputString += "<p>You: Who's there?</p>";
				outputString += "<p>Program: Lettuce</p>";
			}
			else if(jokeCount == 1)
			{
				outputString += "<p>You: Who's there?</p>";
				outputString += "<p>Program: Iva</p>";
			}
			else
			{	
				outputString += "<p>You: Who's there?</p>";
				outputString += "<p>Program:  I'm sorry, I don't understand</p>";
			}
				
		}
		else if (jokeInput.toLowerCase() == "lettuce+who%3f")
		{
			if(jokeCount == 0)
			{
				outputString += "<p>You: Lettuce who?</p>";
				outputString += "<p>Program: Lettuce in it's cold out here!</p>";
				outputString += "<hr/>";
				jokeCount++;
			}
			else
			{	
				outputString += "<p>You: Lettuce who?</p>";
				outputString += "<p>Program:  I'm sorry, I don't understand</p>";
			}
		}
		else if (jokeInput.toLowerCase() == "iva+who%3f")
		{
			if(jokeCount == 1)
			{
				outputString += "<p>You: Iva who?</p>";
				outputString += "<p>Program: Iva sore hand from knocking!</p>";
				outputString += "<hr/>";
				jokeCount++;
			}
			else
			{	
				outputString += "<p>You: Iva who?</p>";
				outputString += "<p>Program:  I'm sorry, I don't understand</p>";
			}
		}
		else if (jokeInput.charAt(0) == "/")
		{
			//Important - without this the localhost automatically sends through a message saying '/favicon.ic'      
		}
		else if (jokeInput.toLowerCase() == "next")
		{
			if(jokeCount == 1)
			{
				outputString += "<p>You: NEXT</p>";
				outputString += "<hr/>";
				outputString += "<p>Program: Knock knock</p>";
			}
			else if (jokeCount > 1)
			{
				outputString += "<p>You: NEXT</p>";
				outputString += "<p>Program: There are no more jokes to tell.</p>";	
				outputString += "<hr/>";
			}
			else
			{
				outputString += "<p>You: NEXT</p>";
				outputString += "<p>Program:  I'm sorry, I don't understand</p>";
			}
		}
		else
		{
			outputString += "<p>You: " + jokeInput + " </p>";
			outputString += "<p>Program: I'm sorry, I don't understand</p>";                      
		}
			  
		//build the output string
		htmlContent = htmlStart + addDiv(outputString) + jokeHTML() + htmlEnd;		  

		// write the response
		response.end(htmlContent);          
	}
 }
).listen(portNumber, ipAddress);
 
 //functions which add HTML to the output ---used in the above line where the output string is built
function addDiv(answer) 
 {
        return "<div class=\"answer\">" + answer + "</div>";
}

function jokeHTML()
{
	var result = "";
	result = "<form id = 'chat' method ='get' action=''><input name = 'mess' type = 'text' placeholder = 'Talk' autofocus/></form>";
        return result;
}